import './App.css'
import Navbar from './components/Navbar.jsx'
import Hero from './components/Hero.jsx'
import BentoGrid from './components/BentoGrid.jsx'
import ServicesSection from './components/ServicesSection.jsx'
import AboutSection from './components/AboutSection.jsx'
import StorySection from './components/StorySection.jsx'
import SimplifiedBooking from './components/SimplifiedBooking.jsx'
import Footer from './components/Footer.jsx'

function App() {
  return (
    <div className="app">
      <Navbar />
      <main id="home">
        <Hero />
        <div className="reveal">
          <BentoGrid />
        </div>
        <div className="reveal">
          <ServicesSection />
        </div>
        <div className="reveal">
          <AboutSection />
        </div>
        <StorySection />
        <SimplifiedBooking />
      </main>
      <Footer />
    </div>
  )
}

export default App
