import React from 'react';
import './BentoGrid.css';
import ExperienceCard from './ExperienceCard';

// Image imports
import lompoul from '../assets/lompoul.png';
import goree from '../assets/goree.png';
import casamance from '../assets/casamance.png';
import lacrose from '../assets/lacrose.png';

const BentoGrid = () => {
  const experiences = [
    { title: "Désert de Lompoul", category: "Aventure", image: lompoul, size: "large" },
    { title: "Île de Gorée", category: "Culture", image: goree, size: "tall" },
    { title: "Mangroves de Casamance", category: "Nature", image: casamance, size: "wide" },
    { title: "Lac Rose", category: "Découverte", image: lacrose, size: "" },
  ];

  return (
    <section className="section-padding bento-section" id="destinations">
      <div className="section-header">
        <span className="sub-title">Expériences Uniques</span>
        <h2 className="section-title text-gradient">Le Sénégal à Travers Vos Yeux</h2>
      </div>
      
      <div className="bento-grid">
        {experiences.map((exp, index) => (
          <ExperienceCard key={index} {...exp} />
        ))}
      </div>
    </section>
  );
};

export default BentoGrid;
