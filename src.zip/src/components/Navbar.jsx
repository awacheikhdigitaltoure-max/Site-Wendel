import React, { useState, useEffect } from 'react';
import './Navbar.css';

const Navbar = () => {
  const [scrolled, setScrolled] = useState(false);

  useEffect(() => {
    const handleScroll = () => {
      setScrolled(window.scrollY > 50);
    };
    window.addEventListener('scroll', handleScroll);
    return () => window.removeEventListener('scroll', handleScroll);
  }, []);

  return (
    <nav className={`navbar ${scrolled ? 'scrolled' : ''}`}>
      <div className="navbar-container">
        <div className="logo font-heading">
          Wëndelu
        </div>
        
        <div className="nav-links">
          <a href="#home">Accueil</a>
          <a href="#destinations">Destinations</a>
          <a href="#services">Services</a>
          <a href="#about">À Propos</a>
          <a href="#booking" className="btn btn-secondary nav-btn">Réserver</a>
        </div>
      </div>
    </nav>
  );
};

export default Navbar;
