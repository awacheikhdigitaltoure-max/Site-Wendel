import React from 'react';
import './AboutSection.css';

const AboutSection = () => {
  return (
    <section className="section-padding about-section" id="about">
      <div className="about-container">
        <div className="about-image glass">
          <div className="image-wrapper">
             {/* Un visuel symbolisant la Teranga ou le Sénégal */}
             <div className="placeholder-image">🇸🇳</div>
          </div>
        </div>
        
        <div className="about-content">
          <span className="sub-title">Notre Vision</span>
          <h2 className="section-title text-gradient">L'Authenticité au Cœur de la Teranga</h2>
          <p>
            Wëndelu est né d'une passion profonde pour le Sénégal. Nous croyons que le voyage est avant tout une rencontre humaine et un échange culturel.
          </p>
          <p>
            Notre mission est de bâtir une marque de tourisme moderne et immersive, profondément ancrée dans l'identité sénégalaise, pour offrir des expériences qui marquent l'esprit et le cœur.
          </p>
          
          <div className="about-stats">
            <div className="stat-item">
              <h3>100%</h3>
              <span>Local</span>
            </div>
            <div className="stat-item">
              <h3>50+</h3>
              <span>Guides</span>
            </div>
            <div className="stat-item">
              <h3>24/7</h3>
              <span>Support</span>
            </div>
          </div>
        </div>
      </div>
    </section>
  );
};

export default AboutSection;
