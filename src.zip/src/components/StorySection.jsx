import React from 'react';
import './StorySection.css';

const StorySection = () => {
  return (
    <section className="section-padding story-section" id="story">
      <div className="story-content reveal">
        <span className="sub-title">L'Âme du Pays</span>
        <h2 className="section-title text-gradient">Plus qu'un voyage, <span className="text-accent">un héritage</span></h2>
        <p className="story-description">
          Le Sénégal ne se visite pas, il se vit. C'est le sourire d'un guide à Saint-Louis, le savoir-faire d'un tisserand à Ngaye Mékhé, et l'écho des tambours au coucher du soleil.
        </p>
        
        <div className="story-grid">
          <div className="story-card glass-card">
            <div className="story-icon">🤝</div>
            <h3>La Teranga</h3>
            <p>Plus qu'une simple hospitalité, c'est l'art de recevoir l'autre comme un frère, au cœur de notre identité.</p>
          </div>
          <div className="story-card glass-card">
            <div className="story-icon">✨</div>
            <h3>Savoir-Faire</h3>
            <p>Nos artisans, de Thiès à Ziguinchor, façonnent l'avenir en préservant les gestes sacrés du passé.</p>
          </div>
          <div className="story-card glass-card">
            <div className="story-icon">🦁</div>
            <h3>Fierté Locale</h3>
            <p>Wëndelu vous connecte directement avec ceux qui font battre le cœur du pays : les locaux.</p>
          </div>
        </div>
        
        <div className="story-quote glass">
          <p>"Au Sénégal, l'invité est un roi. On ne demande pas d'où tu viens, on te demande si tu as faim."</p>
          <span>— Sagesse Locale</span>
        </div>
      </div>
    </section>
  );
};

export default StorySection;
