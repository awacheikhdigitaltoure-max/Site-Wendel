import React from 'react';
import './SimplifiedBooking.css';

const SimplifiedBooking = () => {
  return (
    <section className="section-padding booking-section" id="booking">
      <div className="booking-container glass reveal">
        <div className="booking-info">
          <span className="sub-title" style={{color: 'var(--primary-orange)'}}>Réservation Intuitive</span>
          <h2 className="section-title text-gradient">Préparez votre <br /><span className="text-accent">immersion</span></h2>
          <p className="booking-text">
            Chaque voyage est unique. Nos experts locaux conçoivent pour vous un itinéraire sur mesure qui respecte vos envies et l'authenticité du terrain.
          </p>
          
          <div className="trust-grid">
            <div className="trust-item">
              <div className="trust-icon">✨</div>
              <div>
                <h4>Expertise Locale</h4>
                <p>Guides passionnés et certifiés.</p>
              </div>
            </div>
            <div className="trust-item">
              <div className="trust-icon">🛡️</div>
              <div>
                <h4>Sérénité</h4>
                <p>Paiement 100% sécurisé et assistance 24/7.</p>
              </div>
            </div>
          </div>
        </div>
        
        <div className="booking-card glass-card">
          <form className="booking-form" onSubmit={(e) => e.preventDefault()}>
            <div className="form-group">
              <label>Votre prochaine destination</label>
              <select className="premium-input">
                <option>Désert de Lompoul (Aventure)</option>
                <option>Île de Gorée (Histoire)</option>
                <option>Casamance (Nature Sauvage)</option>
                <option>Lac Rose (Découverte)</option>
              </select>
            </div>
            
            <div className="form-row">
              <div className="form-group">
                <label>Date du départ</label>
                <input type="date" className="premium-input" />
              </div>
              <div className="form-group">
                <label>Nombre de voyageurs</label>
                <input type="number" min="1" defaultValue="1" className="premium-input" />
              </div>
            </div>
            
            <button type="submit" className="btn btn-secondary w-full">Vérifier la disponibilité</button>
            <p className="form-footer">Sans engagement • Réponse sous 24h</p>
          </form>
        </div>
      </div>
    </section>
  );
};

export default SimplifiedBooking;
