import React from 'react';
import './ExperienceCard.css';

const ExperienceCard = ({ title, category, image, size }) => {
  return (
    <div className={`experience-card ${size || ''}`}>
      <div className="card-image">
        <img src={image} alt={title} />
        <div className="card-overlay"></div>
      </div>
      <div className="card-content glass">
        <span className="card-category">{category}</span>
        <h3 className="card-title">{title}</h3>
        <button className="card-btn">Découvrir</button>
      </div>
    </div>
  );
};

export default ExperienceCard;
