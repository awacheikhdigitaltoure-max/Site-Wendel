import React from 'react';
import './Footer.css';

const Footer = () => {
  return (
    <footer className="footer section-padding">
      <div className="footer-container">
        <div className="footer-brand">
          <h2 className="logo font-heading">Wëndelu</h2>
          <p>L'excellence touristique au cœur du Sénégal. Authenticité, Passion et Partage.</p>
          <div className="social-links">
            <span>Instagram</span>
            <span>Facebook</span>
            <span>LinkedIn</span>
          </div>
        </div>
        
        <div className="footer-links">
          <h3>Explorer</h3>
          <a href="#">Destinations</a>
          <a href="#">Expériences</a>
          <a href="#">Guides</a>
          <a href="#">Blog</a>
        </div>
        
        <div className="footer-newsletter">
          <h3>Newsletter Teranga</h3>
          <p>Recevez nos récits de voyage et exclusivités.</p>
          <div className="newsletter-form">
            <input type="email" placeholder="Votre email" />
            <button className="btn btn-primary">S'abonner</button>
          </div>
        </div>
      </div>
      
      <div className="footer-bottom">
        <p>&copy; 2024 Wëndelu - Tous droits réservés. <span className="local-text">Sénégal, Pays de la Teranga 🇸🇳</span></p>
      </div>
    </footer>
  );
};

export default Footer;
