import React from 'react';
import './Hero.css';
import heroImg from '../assets/hero.png';

const Hero = () => {
  return (
    <section className="hero">
      <div className="hero-background">
        <img src={heroImg} alt="Sénégal" />
        <div className="hero-overlay"></div>
      </div>
      
      <div className="hero-content reveal">
        <span className="hero-tagline uppercase tracking-widest">L'Héritage du Lion</span>
        <h1 className="hero-title text-gradient">
          Découvrez l'Âme du <span className="text-accent">Sénégal</span>
        </h1>
        <p className="hero-subtitle">
          Une immersion authentique au cœur d'une terre de Teranga, où chaque instant raconte une histoire millénaire.
        </p>
        <div className="hero-actions">
          <a href="#destinations" className="btn btn-primary">Explorer les Joyaux</a>
          <a href="#story" className="btn btn-outline">Notre Histoire</a>
        </div>
      </div>
      
      <div className="hero-scroll-indicator">
        <div className="mouse">
          <div className="wheel"></div>
        </div>
        <span>Défiler pour explorer</span>
      </div>
    </section>
  );
};

export default Hero;
