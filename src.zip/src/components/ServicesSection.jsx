import React from 'react';
import './ServicesSection.css';

const ServicesSection = () => {
  const services = [
    {
      icon: "🗺️",
      title: "Itinéraires Sur Mesure",
      description: "Des parcours personnalisés selon vos centres d'intérêt (nature, culture, aventure)."
    },
    {
      icon: "👨‍🏫",
      title: "Guides Experts",
      description: "Des accompagnateurs locaux passionnés pour une immersion totale."
    },
    {
      icon: "🚗",
      title: "Transport Premium",
      description: "Des déplacements confortables et sécurisés à travers tout le Sénégal."
    },
    {
      icon: "💎",
      title: "Expériences VIP",
      description: "Accès exclusif à des lieux secrets et rencontres privilégiées."
    }
  ];

  return (
    <section className="section-padding services-section" id="services">
      <div className="section-header">
        <span className="sub-title">Nos Services</span>
        <h2 className="section-title text-gradient">Une Offre d'Excellence</h2>
      </div>
      
      <div className="services-grid">
        {services.map((service, index) => (
          <div key={index} className="service-card glass">
            <div className="service-icon">{service.icon}</div>
            <h3>{service.title}</h3>
            <p>{service.description}</p>
          </div>
        ))}
      </div>
    </section>
  );
};

export default ServicesSection;
